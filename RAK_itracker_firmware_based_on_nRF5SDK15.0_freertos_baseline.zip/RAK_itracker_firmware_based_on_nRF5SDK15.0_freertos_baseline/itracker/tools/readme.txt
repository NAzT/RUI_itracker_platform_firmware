*****************************************************
					User Guide
*****************************************************

We supply a project tool to help you have a quick start.
You can choose the type of mcu and related sensors, and 
then make sure with finish button. It will automatically
config the project according to your choose and open the 
project.

For example, choose like below:
MCU: nRF52832
Sensor: bme280,lis3dh,lis2mdl,opt3001,BG96

It means the product RAK_8212. Now it support RAK_8212 and 
RAK_8211_G, and we will add new product abidingly. And the
config of each product, you can see it from our website below:

https://www.rakwireless.com/en/download


*****************************************************
					Folder
*****************************************************
RAK_CONFIG_TOOL: Tools source code, open with vs2015
head: product config head file
RUI_CONFIG_TOOL.exe: config tools

*****************************************************
					Notice
*****************************************************
When choose and finish, the keil project will open. If 
prompt message is the Synchronization error,just ignore.