#ifndef _BOARD_PLATFORM_H
#define _BOARD_PLATFORM_H

//here define the type of itracker 

#define RAK8212
//#define RAK831

#ifdef RAK8212
#include "board_RAK8212.h"
#endif

#ifdef RAK831
#include "board_RAK831.h"
#endif

#endif
