#ifndef __SENSOR_H__
#define __SENSOR_H__

void start_collect_data();
void sensor_collect_timer_handle();
void sensors_init();

#endif
