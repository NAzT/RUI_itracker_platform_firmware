1. This folder is for app development. You can add your task here and include "itracker.h" which includes the api of all sensors.
2. The project includes two basic tasks, ble and dfu. If you don't need dfu, you can stop it at your task. And If you want to remain
it, add stop cmd in dfu_task where marked when using dfu.