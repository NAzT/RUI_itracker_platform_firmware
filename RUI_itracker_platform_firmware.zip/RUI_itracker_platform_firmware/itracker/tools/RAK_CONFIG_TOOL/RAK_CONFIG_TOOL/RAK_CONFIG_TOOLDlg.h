
// RAK_CONFIG_TOOLDlg.h : ͷ�ļ�
//

#pragma once
#define FALSE 0;
#define TRUE  1;

// CRAK_CONFIG_TOOLDlg �Ի���
class CRAK_CONFIG_TOOLDlg : public CDialogEx
{
// ����
public:
	CRAK_CONFIG_TOOLDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_RAK_CONFIG_TOOL_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCheck1();
	afx_msg void OnBnClickedCheck3();
	afx_msg void OnBnClickedCheck2();
	afx_msg void OnBnClickedCheck4();
	afx_msg void OnBnClickedCheck5();
	afx_msg void OnBnClickedCheck6();
	afx_msg void OnBnClickedCheck7();
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
	bool m_nRF52832;
	bool m_nRF52840;
	bool m_bme280_;
	bool m_lis3dh;
	bool m_lis2mdl;
	bool m_opt3001;
	bool m_L70R;
	bool m_bg96;
	bool m_m35;
};
